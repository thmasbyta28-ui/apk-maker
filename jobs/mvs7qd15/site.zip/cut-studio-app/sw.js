const V='cutstudio-v2',A=['./','index.html','manifest.json','icon-192.png','icon-512.png'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(A)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=V).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{const q=e.request;if(q.method!='GET'||q.headers.has('range'))return;
 e.respondWith(caches.match(q).then(m=>m||fetch(q).then(r=>{if(r&&(r.ok||r.type=='opaque')){const c=r.clone();caches.open(V).then(x=>x.put(q,c))}return r}).catch(()=>caches.match('index.html'))))});

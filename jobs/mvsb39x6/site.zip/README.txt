راهنمای ساخت APK

روش ساده (بدون کدنویسی):
۱. سایت WebIntoApp.com یا AppsGeyser.com را باز کن.
۲. گزینه‌ی ساخت اپ از فایل HTML / ZIP را بزن و همین فایل zip را آپلود کن.
۳. icons/icon-512.png را به‌عنوان آیکون انتخاب کن و APK را دانلود کن.

روش حرفه‌ای (Capacitor + Android Studio):
۱. npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
۲. npx cap init Trader com.example.trader --web-dir=www
۳. محتوای zip را داخل پوشه‌ی www بریز (index.html باید داخل www باشد)
۴. npx cap add android && npx cap sync
۵. npx cap open android و در Android Studio از Build > Build APK استفاده کن.

نکته: ذخیره‌ی بازی با localStorage انجام می‌شود و داخل اپ هم کار می‌کند.
دکمه‌ی دانلود داخل بازی ممکن است در WebView اندروید کار نکند؛ برای APK لازم نیست.
